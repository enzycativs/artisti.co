import "./Leaf978606fd1.css";

const Leaf978606fd1 = () => {
  return <div className="leaf-978606fd-1" />;
};

export default Leaf978606fd1;
